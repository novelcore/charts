{{/*
Expand the name of the chart.
*/}}
{{- define "kubecore-ci-workflows.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "kubecore-ci-workflows.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kubecore-ci-workflows.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kubecore-ci-workflows.labels" -}}
helm.sh/chart: {{ include "kubecore-ci-workflows.chart" . }}
{{ include "kubecore-ci-workflows.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: kubecore
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kubecore-ci-workflows.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubecore-ci-workflows.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "kubecore-ci-workflows.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kubecore-ci-workflows.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the namespace name
*/}}
{{- define "kubecore-ci-workflows.namespace" -}}
{{- default .Release.Namespace .Values.workflow.namespace }}
{{- end }}

{{/*
User-managed CI secrets (kaos PRD 695, spec section 6.2) for the service
build-push steps of ci-build and ci-rc-build.

The operator renders two ExternalSecrets in {project}-ci, where these
workflows run: {project}-ci-secrets (KubeProject.spec.ci.secretBindings) and
{project}-{app}-ci-secrets (KubeApp secretBindings.ci; the app secret is
namespaced by project to avoid colliding with the project secret when an app
is named like its project). Their keys are p_{name}_{KEY} / o_{name}_{KEY}.
Both are OPTIONAL: a project or app with no CI bindings has no such Secret,
the kubelet mounts an empty directory, and the build is exactly what it was
before.

The raw Secrets are mounted ONLY into the ci-secrets-prep init container. The
kaniko container sees the laid-out copy on a memory-backed emptyDir at
/kaniko/secrets, which kaniko never snapshots into a layer.
*/}}
{{- define "kubecore-ci-workflows.ciSecretsVolumes" -}}
- name: ci-secrets-project
  secret:
    secretName: "{{`{{workflow.parameters.project_name}}`}}-ci-secrets"
    optional: true
- name: ci-secrets-app
  secret:
    secretName: "{{`{{workflow.parameters.project_name}}`}}-{{`{{workflow.parameters.app_name}}`}}-ci-secrets"
    optional: true
- name: kaniko-secrets
  emptyDir:
    medium: Memory
    sizeLimit: 16Mi
{{- end }}

{{/*
ci-secrets-prep init container: lays out /kaniko/secrets and writes
/kaniko/.docker/config.json (platform push credential + user registries).
It replaces the docker-config block the kaniko container used to run inline;
see files/ci-secrets-prep.sh and tests/ci-secrets-prep/run.sh. Runs as root
so the files it writes carry the same ownership kaniko (root) had before.
*/}}
{{- define "kubecore-ci-workflows.ciSecretsPrepInitContainer" -}}
- name: ci-secrets-prep
  image: {{ .Values.ciSecretsPrep.image | default "mikefarah/yq:4.44.3" }}
  {{- include "kubecore-ci-workflows.resources" .Values.tooling.resources | nindent 2 }}
  command: [sh, -c]
  securityContext:
    runAsUser: 0
    runAsGroup: 0
  env:
  - name: REGISTRY
    value: {{ .Values.registry.internalUrl | quote }}
  - name: REGISTRY_TYPE
    value: "{{`{{workflow.parameters.registry_type}}`}}"
  - name: IMAGE_REPO
    value: "{{`{{workflow.parameters.image_repo}}`}}"
  args:
  - |
{{ .Files.Get "files/ci-secrets-prep.sh" | indent 4 }}
  volumeMounts:
  - name: ci-secrets-project
    mountPath: /etc/ci-secrets/project
    readOnly: true
  - name: ci-secrets-app
    mountPath: /etc/ci-secrets/app
    readOnly: true
  - name: registry-auth
    mountPath: /etc/registry-auth
    readOnly: true
  - name: kaniko-secrets
    mountPath: /kaniko/secrets
  - name: kaniko-config
    mountPath: /kaniko/.docker
{{- end }}

{{/*
files/engine.py (PRD-HPC-1461 D-80): the platform pipeline engine's context check, wheel fetch and stamp,
written to /tmp/engine.py. Tested in tests/engine (pytest) and tests/engine-ci (the scripts that call it).
Caller: python3 + PyYAML (tooling.toolboxImage). Run as `python3 -I`.
*/}}
{{- define "kubecore-ci-workflows.engineScript" -}}
cat > /tmp/engine.py <<'ENGINEPYEOF'
{{ .Files.Get "files/engine.py" }}
ENGINEPYEOF
{{- end }}

{{/*
The chart-owned compose-and-validate Dockerfile (files/compose.Dockerfile), written to
${COMPOSE_DOCKERFILE} by the steps that need it (detect-steps for the kaos-lib check, build-push to build
it); the app's config/ folder is the build context.
*/}}
{{- define "kubecore-ci-workflows.composeDockerfile" -}}
cat > "${COMPOSE_DOCKERFILE}" <<'COMPOSEDOCKEREOF'
{{ .Files.Get "files/compose.Dockerfile" }}
COMPOSEDOCKEREOF
{{- end }}

{{/*
Enhance with the engine of this build (PRD-HPC-1461 D-80) on the raw WFT the engine render wrote, isolated
from the app checkout (kubecore-operator#1375). Used by the two token-holding steps, hera-enhance-commit
(merge) and hera-enhance-gate (PR). The engine wheel the context pins is downloaded, verified by its
sha256 and unzipped OUTSIDE the workspace (no pip, nothing of the app's on sys.path: /workspace/repo is
developer-controlled and hera-render just ran untrusted pipeline.py against it). A wheel that does not
download or whose sha256 differs FAILS the step: enhancing with unknown code is not an option. The WFT is
then stamped with the engine version (annotation, and the `platform.kubecore.io/engine` run label).
Last, the step table the engine wrote on the compose step (PRD novelcore/kaos#1911: what every step reads
and produces) is read into /tmp/steps.json. A render without one is not from an engine on the step
contract: the step fails and nothing is committed (`engine.py steps`, exit 6).

Caller: ENGINE_JSON set (the `engine.py context` JSON of detect-steps/detect-engine, an immutable Argo
parameter), PyYAML installed, /tmp/context.yaml written, the raw WFT at
/workspace/out/raw-workflow-template.yaml. Writes /workspace/out/workflow-template.yaml and
/tmp/steps.json, and sets ENGINE_VERSION.
*/}}
{{- define "kubecore-ci-workflows.platformEnhance" -}}
{{ include "kubecore-ci-workflows.engineScript" . }}
ENGINE_VERSION=$(printf '%s' "${ENGINE_JSON:-}" | jq -r '.version // ""')
ENGINE_WHEEL=$(printf '%s' "${ENGINE_JSON:-}" | jq -r '.wheel // ""')
ENGINE_WHEEL_SHA256=$(printf '%s' "${ENGINE_JSON:-}" | jq -r '.wheel_sha256 // ""')
[ -n "${ENGINE_VERSION}" ] || { echo "engine: FATAL: no engine for this build" >&2; exit 1; }
rm -rf /tmp/kubecore-engine
ENGINE_DIR=$(python3 -I /tmp/engine.py fetch --wheel "${ENGINE_WHEEL}" --sha256 "${ENGINE_WHEEL_SHA256}" --dest /tmp/kubecore-engine)
echo "platform enhancer: engine ${ENGINE_VERSION} (wheel sha256 $(printf %s "${ENGINE_WHEEL_SHA256}" | cut -c1-12) verified) unpacked to ${ENGINE_DIR}"
( cd "${ENGINE_DIR}" && python3 -m kubecore.enhance \
    --raw /workspace/out/raw-workflow-template.yaml \
    --context /tmp/context.yaml \
    --output /workspace/out/workflow-template.yaml \
    --helper-configmap /workspace/out/ckpt-helper.yaml \
    --form-data /tmp/form-data.json )
python3 - /workspace/out/workflow-template.yaml /tmp/context.yaml <<'STEPTOKEOF'
import sys
import yaml
{{ include "kubecore-ci-workflows.stepToken" . }}
wft_path, ctx_path = sys.argv[1:3]
wft, ctx = yaml.safe_load(open(wft_path)), yaml.safe_load(open(ctx_path)) or {}
if add_step_token(wft, ctx):
    yaml.dump(wft, open(wft_path, "w"), default_flow_style=False, allow_unicode=True, sort_keys=False)
STEPTOKEOF
python3 -I /tmp/engine.py stamp --wft /workspace/out/workflow-template.yaml --version "${ENGINE_VERSION}"
python3 -I /tmp/engine.py steps --wft /workspace/out/workflow-template.yaml > /tmp/steps.json
{{- end }}

{{/*
files/run_form.py (PRD novelcore/kaos#1533 F-21/F-22): the trusted run-form seal, written to /tmp/kaos-run-form/run_form.py.
Chart-owned code, not the engine's: it imports nothing from the engine and runs only as `python3 -I`, so a file in
the checkout, the output directory or the working directory is never imported. It holds no `{{`, which Argo would
read as a template tag (tests/run-form-seal). Tested in tests/run-form-seal.
Caller: python3 + PyYAML (tooling.toolboxImage).
*/}}
{{- define "kubecore-ci-workflows.runFormScript" -}}
mkdir -p /tmp/kaos-run-form
cat > /tmp/kaos-run-form/run_form.py <<'RUNFORMPYEOF'
{{ .Files.Get "files/run_form.py" }}
RUNFORMPYEOF
{{- end }}

{{/*
Run-form seal (PRD novelcore/kaos#1533, F-21/F-22): after the enhance and the dataset fill, the trusted seal
(`files/run_form.py`) builds the run form from data the trusted enhance wrote (/tmp/form-data.json), the step table
(/tmp/steps.json), the context and config/_form.yaml, stamps it (engine version, source commit, params digest) and writes
it to the WorkflowTemplate's annotations, in place. It is the only writer of `ui.kubecore.io/run-form`. Used by
hera-enhance-commit (merge: `previous` true, the live gitops template, so an unchanged render keeps its commit) and
hera-enhance-gate (PR: no previous). There is no skip branch: a seal that fails fails the step with its
`GATE FAIL: run form: ...` text, before anything is committed (fail-closed). The commit comes in through the
COMMIT_SHA env var, never spliced into the script, and must be 40 lowercase hex. Run as `python3 -I`, from any
directory, with the arguments built in a subshell.
Caller: ENGINE_VERSION set (platformEnhance), COMMIT_SHA in the env; `previous` also needs GITOPS_DIR.
Usage: include "kubecore-ci-workflows.runFormSeal" (dict "previous" true "Files" .Files)
*/}}
{{- define "kubecore-ci-workflows.runFormSeal" -}}
{{ include "kubecore-ci-workflows.runFormScript" . }}
case "${COMMIT_SHA:-}" in
  *[!0-9a-f]*|"") echo "GATE FAIL: run form: the source commit is not 40 lowercase hex characters" >&2; exit 1 ;;
esac
[ "${#COMMIT_SHA}" -eq 40 ] || { echo "GATE FAIL: run form: the source commit is not 40 lowercase hex characters" >&2; exit 1; }
(
  set -- --wft /workspace/out/workflow-template.yaml --context /tmp/context.yaml --form-data /tmp/form-data.json \
    --steps /tmp/steps.json --config-dir /workspace/repo/config --engine "${ENGINE_VERSION}" --source-commit "${COMMIT_SHA}"
{{- if .previous }}
  if [ -f "${GITOPS_DIR}/workflow-template.yaml" ]; then
    set -- "$@" --previous "${GITOPS_DIR}/workflow-template.yaml"
  fi
{{- end }}
  python3 -I /tmp/kaos-run-form/run_form.py seal "$@"
) || { echo "run form: the seal failed; nothing is committed" >&2; exit 1; }
{{- end }}

{{/*
Size guard for a rendered WorkflowTemplate. Run as `python3 - <wft> <summary|""> <<'EOF'`.
Fails the render, with the biggest templates named, when the file exceeds
wftSize.limitKiB (the etcd object limit is ~1.5 MiB; Argo CD applies the
object server-side, so the 256 KiB last-applied annotation limit no longer
applies, but a render near etcd's limit would stop updating the app silently).
Prints `wft-size: <bytes>`, and appends the size to the PR status summary file.
*/}}
{{- define "kubecore-ci-workflows.wftSizeGuard" -}}
import json, sys, yaml
wft_path, summary = sys.argv[1], sys.argv[2]
limit = {{ int .Values.wftSize.limitKiB }} * 1024
raw = open(wft_path, "rb").read()
size = len(raw)
print(f"wft-size: {size} bytes ({size / 1024:.1f} KiB, limit {limit // 1024} KiB)")
if summary:
    open(summary, "a").write(f", {size / 1024:.0f} KiB")
if size > limit:
    spec = yaml.safe_load(raw)["spec"]
    per = sorted(((len(json.dumps(t)), t["name"]) for t in spec.get("templates", [])), reverse=True)
    print(f"GATE FAIL: the rendered WorkflowTemplate is {size / 1024:.0f} KiB, over the {limit // 1024} KiB limit "
          "(etcd stores an object of at most ~1.5 MiB; past that Argo CD cannot apply the pipeline and the app stops updating).")
    print("Biggest templates: " + ", ".join(f"{n} {b / 1024:.1f} KiB" for b, n in per[:5]))
    print("Fix: split the pipeline into smaller ones, or remove steps; platform-injected per-step blocks are already shared.")
    sys.exit(1)
{{- end }}

{{/*
The two sentences an app made before the current pipelines is told (PRD novelcore/kaos#1911): the owner's
ruling is that no app is moved, an old app is created again from the template. The engine ends its refusals of
such an app with them (its OLD_APP_NOTICE; the second sentence is the `old_app_marker` of its authoring schema).
*/}}
{{- define "kubecore-ci-workflows.oldAppNotice" -}}
This app was made before the current pipelines. Create it again from the template.
{{- end }}

{{/*
The commit status of a build that was refused because the app is an old app (PRD novelcore/kaos#1911 AC-01).
GitHub cuts a description at 140 characters: tests/step-contract checks it fits.
*/}}
{{- define "kubecore-ci-workflows.oldAppStatus" -}}
Not built: this app was made before the current pipelines. Create it again from the template.
{{- end }}

{{/*
old_app MESSAGE (PRD novelcore/kaos#1911 AC-01, T-05): this app was made before the current pipelines and
the caller is about to fail. MESSAGE is the refusal as the engine (or the kaos-lib check) words it: a
sentence that says what is wrong, then the notice above. Nothing was committed and nothing is built; this
only leaves what the app's engineer reads, for the steps that report:
  /workspace/old-app           one line, the reason (MESSAGE without the notice; the exit handler turns it
                               into the commit status, the `engine-last-error` record and the one-attempt
                               record)
  /workspace/report-extra.md   the "What to change" section of the report comment (the report template
                               appends that file)
and one `kaos-ci: OLD APP:` line in the step's log. The message is data: control characters and backticks
are dropped and it is cut at 600 characters. It names no platform internals.
Caller: /workspace mounted and writable; POSIX sh.
*/}}
{{- define "kubecore-ci-workflows.oldApp" -}}
old_app() {
  _nm=$(printf '%s' "$1" | tr '\n\r\t' '   ' | tr -d '\000-\037\177`' | cut -c1-600)
  _why=$(printf '%s' "${_nm%"{{ include "kubecore-ci-workflows.oldAppNotice" . }}"}" | sed 's/ *$//')
  printf '%s\n' "${_why}" > /workspace/old-app
  {
    echo "#### What to change"
    echo ""
    echo "This app was made before the current pipelines. It was not built: the pipeline you could run before this commit is still the one that runs."
    if [ -n "${_why}" ]; then
      echo ""
      echo '```'
      echo "${_why}"
      echo '```'
    fi
    echo ""
    echo "Create it again from the template."
    echo ""
  } > /workspace/report-extra.md
  echo "kaos-ci: OLD APP: ${_nm}" >&2
}
{{- end }}

{{/*
The step's service-account token for kaos-lake (PRD novelcore/kaos#1217 F-05).
Python source of add_step_token(wft, ctx): when the pipeline context carries
workloadIdentity.audience, every container template that runs as the app's own
account (ctx.serviceAccountName, else the WFT's) gets a projected, audience-bound
token mounted read-only at /var/run/secrets/kaos-lake and KAOS_LAKE_TOKEN_FILE
pointing at it. Returns how many templates it changed; with no audience it changes
nothing, so existing renders stay byte-identical. The volume name and mount path
are the ones the enhance step itself uses for the dataset catalog. Shared by
the enhance steps (platformEnhance), which cannot import it.
*/}}
{{- define "kubecore-ci-workflows.stepToken" -}}
def add_step_token(wft, ctx):
    audience = ((ctx or {}).get("workloadIdentity") or {}).get("audience")
    if not audience:
        return 0
    spec = wft["spec"]
    account = (ctx or {}).get("serviceAccountName") or "argo-workflow"
    changed = 0
    for t in spec.get("templates") or []:
        c = t.get("container")
        if not c or (t.get("serviceAccountName") or spec.get("serviceAccountName")) != account:
            continue
        vols = t.setdefault("volumes", [])
        if not any(v.get("name") == "kaos-lake-token" for v in vols):
            vols.append({"name": "kaos-lake-token", "projected": {"sources": [
                {"serviceAccountToken": {"audience": audience, "expirationSeconds": 3600, "path": "token"}}]}})
        mounts = c.setdefault("volumeMounts", [])
        if not any(m.get("name") == "kaos-lake-token" for m in mounts):
            mounts.append({"name": "kaos-lake-token", "mountPath": "/var/run/secrets/kaos-lake", "readOnly": True})
        env = c.setdefault("env", [])
        if not any(e.get("name") == "KAOS_LAKE_TOKEN_FILE" for e in env):
            env.append({"name": "KAOS_LAKE_TOKEN_FILE", "value": "/var/run/secrets/kaos-lake/token"})
        changed += 1
    return changed
{{- end }}

{{/*
Create and push an annotated tag on workflow.parameters.commit_sha from a FRESH
repository (kubecore-operator#1375). Never from /workspace/repo: earlier steps
ran developer code with write access to that checkout (pipeline.py in
hera-render, Dockerfile RUN in the image build), and a hook or .git/config
entry planted there would run on this push, next to the token.

Caller: TOKEN, TAG and TAG_MESSAGE set; image has git; gitAuth included (the
token reaches git as a header, the URL below carries none).
*/}}
{{- define "kubecore-ci-workflows.pushTag" -}}
{{ include "kubecore-ci-workflows.gitAuth" . }}
REPO_URL="{{`{{workflow.parameters.repo_url}}`}}"
COMMIT="{{`{{workflow.parameters.commit_sha}}`}}"
rm -rf /tmp/tagrepo
git init -q /tmp/tagrepo
cd /tmp/tagrepo
git config user.name "KubeCore CI"
git config user.email "ci@kubecore.io"
# GitHub now and then answers a push with a 5xx ("remote: Internal Server
# Error", kaos e2e-suite-zgbzw 2026-10-26). The step exits 1 on it, which its
# retryStrategy rightly does not retry (it retries only lost pods), so the
# push is tried up to TAG_PUSH_TRIES times here. Every try re-reads the tag
# first, so a push GitHub applied before answering 5xx is found, not redone.
TAG_PUSH_TRIES=4
TRY=1
while :; do
  # A retried attempt may find the tag its predecessor already pushed (#1379):
  # the same commit is success, another commit is a real conflict.
  EXISTING=$(git ls-remote "${REPO_URL}" "refs/tags/${TAG}^{}" "refs/tags/${TAG}" | head -1 | cut -f1)
  if [ -n "${EXISTING}" ]; then
    git fetch -q --depth=1 "${REPO_URL}" "refs/tags/${TAG}:refs/tags/${TAG}"
    if [ "$(git rev-parse "refs/tags/${TAG}^{commit}")" != "${COMMIT}" ]; then
      echo "Tag ${TAG} already exists on another commit"; exit 1
    fi
    echo "Tagged: ${TAG} (already present on ${COMMIT})"
    break
  fi
  if git fetch -q --depth=1 "${REPO_URL}" "${COMMIT}" \
      && git tag -f -a "${TAG}" -m "${TAG_MESSAGE}" "${COMMIT}" \
      && git push -q "${REPO_URL}" "refs/tags/${TAG}"; then
    echo "Tagged: ${TAG}"
    break
  fi
  if [ "${TRY}" -ge "${TAG_PUSH_TRIES}" ]; then
    echo "Tag ${TAG}: push failed ${TRY} times"; exit 1
  fi
  echo "Tag ${TAG}: push failed (try ${TRY}/${TAG_PUSH_TRIES}), retrying in $((TRY * 15))s"
  sleep $((TRY * 15))
  TRY=$((TRY + 1))
done
{{- end }}

{{/*
GitHub auth for git that never writes the token to disk (kaos PRD 738 F-20).

The token used to ride in the clone URL (https://x-access-token:TOKEN@github.com/…),
and git persists a clone URL as remote.origin.url in .git/config. /workspace/repo
is the kaniko build context, so a Dockerfile `RUN cat .git/config` read a live
org GitHub App token, and `COPY . .` baked it into an image layer pushed to the
registry. Every step that cloned that way left the token behind.

Now every URL is token-free and `git` is a shell function that hands the token
to the one git process it starts, as an HTTP Authorization header in
GIT_CONFIG_* environment variables (git >= 2.31; every CI image ships 2.45+).
Nothing reaches .git/config, nothing is exported to the script's other
children, and fetch/push from a clone keep working because each call
re-authenticates. The header is scoped to https://github.com/ only.

git_assert_no_token DIR fails the step if DIR/.git/config holds a credential
of any form — a guard against a future edit reintroducing the URL form.

Caller: TOKEN set (empty = unauthenticated git, as before).
*/}}
{{- define "kubecore-ci-workflows.gitAuth" -}}
# git with the GitHub App token as a per-process header (PRD 738 F-20): the
# token never lands in .git/config. URLs below are plain https://github.com/…
git() {
  if [ -n "${TOKEN:-}" ]; then
    env GIT_CONFIG_COUNT=1 \
      GIT_CONFIG_KEY_0="http.https://github.com/.extraheader" \
      GIT_CONFIG_VALUE_0="Authorization: Basic $(printf 'x-access-token:%s' "${TOKEN}" | base64 | tr -d '\n')" \
      git "$@"
  else
    env git "$@"
  fi
}
git_assert_no_token() {
  _gcfg="$1/.git/config"
  [ -f "${_gcfg}" ] || return 0
  if grep -qiE 'x-access-token|extraheader|://[^/@[:space:]]+@' "${_gcfg}" \
     || { [ -n "${TOKEN:-}" ] && grep -qF -- "${TOKEN}" "${_gcfg}"; }; then
    echo "FATAL: ${_gcfg} holds a GitHub credential (PRD 738 F-20)" >&2
    exit 1
  fi
}
{{- end }}

{{/*
Build pods: no Kubernetes ServiceAccount token in the build container
(kaos PRD 738 F-20).

The kaniko container runs the tenant's Dockerfile, so whatever it can read, a
`RUN` step can read. It needs no Kubernetes API access: its registry auth is a
docker config file, GAR auth is GKE Workload Identity (the metadata server,
not a token mount). Argo's own executor still needs the pod SA's token — the
`init` container and the `wait` sidecar create/patch WorkflowTaskResults; the
emissary in the main container talks to no API.

Argo's built-in route (template automountServiceAccountToken: false +
executor.serviceAccountName) needs a long-lived `<sa>.service-account-token`
Secret for the executor SA in every project CI namespace — the operator creates
one only for ML apps' hera-render-exec. So instead this patch turns automount
off for the whole pod and mounts a projected, short-lived token of the SAME
pod ServiceAccount into Argo's `init` and `wait` containers only, at the
standard path: exactly the volume the kubelet would have mounted everywhere.
The main (build) container gets nothing. No Secret, no new SA, no new RBAC.
*/}}
{{- define "kubecore-ci-workflows.buildPodSpecPatch" -}}
{{- if .Values.buildPods.isolateServiceAccountToken }}
podSpecPatch: |
  automountServiceAccountToken: false
  volumes:
  - name: kubecore-executor-sa-token
    projected:
      defaultMode: 420
      sources:
      - serviceAccountToken:
          path: token
          expirationSeconds: 3607
      - configMap:
          name: kube-root-ca.crt
          items:
          - key: ca.crt
            path: ca.crt
      - downwardAPI:
          items:
          - path: namespace
            fieldRef:
              apiVersion: v1
              fieldPath: metadata.namespace
  initContainers:
  - name: init
    volumeMounts:
    - name: kubecore-executor-sa-token
      mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      readOnly: true
  containers:
  - name: wait
    volumeMounts:
    - name: kubecore-executor-sa-token
      mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      readOnly: true
{{- end }}
{{- end }}

{{/*
The clone of a just-created app repository can run before the project's CI
token covers it (kaos PRD 738 F-59): the token is scoped to the project's
repositories that already exist, and the re-scope reaches the pool ~1 min after
the repository does — while its push webhook is already live. GitHub answers
that clone "Repository not found" (kaos e2e-suite-mn8rc, 2026-10-09: the first
push's clone ran 4s before the re-scoped token landed, and the build failed).

git_clone exits 75 (EX_TEMPFAIL) on exactly that answer so cloneRetry retries
it in a NEW pod, which mounts the re-scoped token; every other clone failure
keeps git's own exit code and is not retried. GitHub's answer is always logged.

Caller: the gitAuth wrapper defined (git_clone calls git through it).
*/}}
{{- define "kubecore-ci-workflows.gitClone" -}}
git_clone() {
  _rc=0
  _out=$(git clone "$@" 2>&1) || _rc=$?
  printf '%s\n' "${_out}"
  if [ "${_rc}" -ne 0 ] && printf '%s' "${_out}" | grep -q "Repository not found"; then
    echo "The CI token does not reach this repository yet: a new app's repository joins the project's CI token scope about a minute after it is created. Exiting 75 so the step retries with the re-scoped token." >&2
    exit 75
  fi
  return "${_rc}"
}
{{- end }}

{{/*
preemptionRetry plus exit 75: git_clone's "the CI token does not reach this
repository yet" (see gitClone). Same limit and backoff (30s, then 60s), so the
clone gets ~90s for the token to catch up.
*/}}
{{- define "kubecore-ci-workflows.cloneRetry" -}}
retryStrategy:
  limit: "2"
  retryPolicy: Always
  expression: 'lastRetry.status == "Error" or lastRetry.message matches "imminent node shutdown" or lastRetry.exitCode == "75"'
  backoff:
    duration: "30s"
    factor: "2"
{{- end }}

{{/*
Retry a step whose pod was lost to the infrastructure (kubecore-operator#1379):
an Argo Error, or a pod killed by a spot preemption ("imminent node shutdown").
Same policy as ci-build's steps; a genuine failure (non-zero exit with any
other message) is NOT retried. No backoff.maxDuration: Argo counts it from the
first attempt's start, so a cap cancels the retry of any step that ran past it
(kubecore-operator#1377). Every step using it must be safe to re-run.
*/}}
{{- define "kubecore-ci-workflows.preemptionRetry" -}}
retryStrategy:
  limit: "2"
  retryPolicy: Always
  expression: 'lastRetry.status == "Error" or lastRetry.message matches "imminent node shutdown"'
  backoff:
    duration: "30s"
    factor: "2"
{{- end }}


{{/*
kubectl for a step that runs the gcloud alpine image (tooling.gcloudImage),
which ships gcloud + python3 but no kubectl. Instead of installing kubectl when
the pod starts (`gcloud components install kubectl` took 9-18 minutes on a busy
system node), an init container copies the static binary from the pinned
tooling.kubectlBinaryImage into the "kubectl-bin" emptyDir. The step mounts it
at /opt/kubectl-bin and puts that on its PATH. A template that includes this
also needs the kubectlBinVolume and kubectlBinMount below.
*/}}
{{- define "kubecore-ci-workflows.kubectlBinInit" -}}
initContainers:
- name: kubectl-bin
  image: {{ .Values.tooling.kubectlBinaryImage | default "alpine/kubectl:1.36.4" }}
  command: [cp, /usr/local/bin/kubectl, /opt/kubectl-bin/kubectl]
  {{- with .Values.tooling.resources }}
  resources:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  volumeMounts:
  - name: kubectl-bin
    mountPath: /opt/kubectl-bin
{{- end }}

{{- define "kubecore-ci-workflows.kubectlBinVolume" -}}
- name: kubectl-bin
  emptyDir: {}
{{- end }}

{{- define "kubecore-ci-workflows.kubectlBinMount" -}}
- name: kubectl-bin
  mountPath: /opt/kubectl-bin
  readOnly: true
{{- end }}

{{/*
A step's resources block from a tooling.*Resources (or kaniko.*Resources)
value. Requests keep these pods out of the BestEffort class. Usage:
  image: ...
  {{- include "kubecore-ci-workflows.resources" .Values.tooling.resources | nindent 6 }}
*/}}
{{- define "kubecore-ci-workflows.resources" -}}
{{- with . }}
resources:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{/*
GitHub REST calls from a reporting step, with retries. Every call used to be a
single `curl -s` whose HTTP status was thrown away, so one transient answer
(5xx, a secondary rate limit) silently dropped a write: in kaos
e2e-suite-devmove-g77qv (2026-10-14) the success step could not resolve the
run's Deployment, logged a WARN, exited 0, and the Deployment stayed
in_progress forever.

gh_api METHOD URL [DATA] retries what is transient: no answer (curl transport
error), HTTP 429, 5xx, and a 403 that is a secondary rate limit (a Retry-After
header or GitHub's "secondary rate limit" message). 5 attempts, backoff
2/4/8/16s; a numeric Retry-After replaces the backoff (capped at 60s). It sets
GH_CODE (the HTTP status, "000" = no answer) and GH_BODY, logs every failed
answer with GitHub's message, and returns 0 on 2xx, 75 when GitHub stayed
unavailable (a new pod may succeed: githubReportRetry retries exit 75), 1 on
any other answer (a real refusal: retrying changes nothing). The token only
travels in the AUTH header and is never logged.

HTTP 404 returns 75 at once: the CI token does not reach the repository yet.
It is the API side of the race gitClone (0.12.109) handles for the clone: a
new app's repository joins the project's CI token scope after it is created,
while its push webhook is already live. In kaos e2e run 1c114130 (2026-10-18,
ml-ci-build-6mfoi, first build 228s after the app was created) the pending
step's three calls all answered 404 at 12:35:15, the step exited 1 (not
retried), and the success step posted its commit status fine at 12:38:43: no
GitHub Deployment ever existed for the build. GitHub answers 404, not 403, for
a repository a token cannot see, so 404 is that race, not a refusal. Retrying
in this pod is pointless (AUTH holds the token read at start); a new pod mounts
the re-scoped one, so 404 goes straight to githubReportRetry. 401/403/422 stay
a refusal (1).

Caller: AUTH and ACCEPT set; image has curl.
*/}}
{{- define "kubecore-ci-workflows.ghApi" -}}
gh_api() {
  _gm="$1"; _gu="$2"; _gd="${3:-}"; _gn=1; _gw=2; _gt=$(mktemp -d)
  while :; do
    : > "${_gt}/hdr"; : > "${_gt}/body"
    GH_CODE=$(curl -sS -o "${_gt}/body" -D "${_gt}/hdr" -w '%{http_code}' \
      --connect-timeout 10 --max-time 30 -X "${_gm}" -H "${AUTH}" -H "${ACCEPT}" \
      ${_gd:+-d} ${_gd:+"${_gd}"} "${_gu}") || GH_CODE="000"
    GH_BODY=$(cat "${_gt}/body")
    _gr=""
    case "${GH_CODE}" in
      2??) rm -rf "${_gt}"; return 0 ;;
      000|429|5??) _gr=1 ;;
      403) if grep -qi '^retry-after:' "${_gt}/hdr" \
              || printf '%s' "${GH_BODY}" | grep -qi 'secondary rate limit'; then _gr=1; fi ;;
    esac
    _gx=$(printf '%s' "${GH_BODY}" | tr -d '\n' | cut -c1-200)
    if [ "${GH_CODE}" = 404 ]; then
      echo "GitHub ${_gm} ${_gu#https://api.github.com} answered HTTP 404: ${_gx} — the CI token does not reach this repository yet: a new app's repository joins the project's CI token scope after it is created. Exiting 75 so the step retries with the re-scoped token." >&2
      rm -rf "${_gt}"; return 75
    fi
    if [ -z "${_gr}" ]; then
      echo "GitHub ${_gm} ${_gu#https://api.github.com} answered HTTP ${GH_CODE}: ${_gx}" >&2
      rm -rf "${_gt}"; return 1
    fi
    if [ "${_gn}" -ge 5 ]; then
      echo "GitHub ${_gm} ${_gu#https://api.github.com} still unavailable after ${_gn} attempts (last HTTP ${GH_CODE}): ${_gx}" >&2
      rm -rf "${_gt}"; return 75
    fi
    _gs=$(grep -i '^retry-after:' "${_gt}/hdr" | tail -1 | tr -d '\r' | awk '{print $2}')
    case "${_gs}" in ''|*[!0-9]*) _gs="${_gw}" ;; esac
    [ "${_gs}" -le 60 ] || _gs=60
    echo "GitHub ${_gm} ${_gu#https://api.github.com} answered HTTP ${GH_CODE} (attempt ${_gn}/5), retrying in ${_gs}s" >&2
    sleep "${_gs}"
    _gn=$((_gn + 1)); _gw=$((_gw * 2))
  done
}
{{- end }}

{{/*
The GitHub reporting of a build (#1126), shared by the status templates of
ci-build, ci-rc-build and ml-ci-build: ONE commit status with target_url into the Argo UI run, plus
a Deployment rollup whose log/environment URL is the same run. pending creates
the Deployment; success/failure resolve the Deployment created for this SHA +
environment, and create it themselves when none is listed after 5 lookups (the
pending step could not create it, e.g. a brand-new repo the CI token did not
reach yet: see ghApi).

Every call goes through gh_api (ghApi above). A write that still fails no
longer ends in a WARN and exit 0: the step exits 75 (GitHub unavailable, or
the CI token does not reach the repo yet (404); retried in a new pod by
githubReportRetry) or 1 (GitHub refused), with the HTTP status in the log. Every caller runs
the step with continueOn failed, so a reporting failure is a red status node
in the Argo run, never a red (or stopped) build. The commit status and the
Deployment are attempted independently; the exit code is the worst of the two.

Caller: SHA, STATE, DESC, CONTEXT, ENVIRONMENT ("" = statuses only), API,
AUTH, ACCEPT, RUN_URL ("" = no link) and OWNER_REPO set; image has curl and jq.
*/}}
{{- define "kubecore-ci-workflows.githubStatusReport" -}}
{{ include "kubecore-ci-workflows.ghApi" . }}
REPORT_RC=0
report_failed() {
  echo "ERROR: $2 (HTTP ${GH_CODE})" >&2
  [ "${REPORT_RC}" = 75 ] || REPORT_RC="$1"
}

# 1) commit status — the check on the commit / PR, linking to the run.
if [ -n "${RUN_URL}" ]; then
  PAYLOAD="{\"state\":\"${STATE}\",\"description\":\"${DESC}\",\"context\":\"${CONTEXT}\",\"target_url\":\"${RUN_URL}\"}"
else
  PAYLOAD="{\"state\":\"${STATE}\",\"description\":\"${DESC}\",\"context\":\"${CONTEXT}\"}"
fi
if gh_api POST "${API}/statuses/${SHA}" "${PAYLOAD}"; then
  echo "Posted commit status ${CONTEXT}=${STATE} on ${OWNER_REPO}@${SHA}"
else
  report_failed $? "commit status ${CONTEXT}=${STATE} not posted on ${OWNER_REPO}@${SHA}"
fi

# 2) Deployment rollup (environment = this pipeline). Created on pending
# with required_contexts:[] — THIS run is what the commit statuses
# describe; defaulting would deadlock the Deployment on its own check.
# Resolved on success/failure against the Deployment created for this
# SHA + environment. jq for response parsing (compact vs pretty JSON
# both occur; baked into tooling.toolboxImage); without jq the
# statuses still stand.
if [ -z "${ENVIRONMENT}" ]; then
  :
elif ! command -v jq >/dev/null; then
  echo "WARN: jq unavailable — commit status posted, deployment rollup skipped"
else
  DEP_ID=""
  # This run's Deployment for SHA + ENVIRONMENT. Sets DEP_ID on success.
  create_deployment() {
    if gh_api POST "${API}/deployments" \
         "{\"ref\":\"${SHA}\",\"environment\":\"${ENVIRONMENT}\",\"auto_merge\":false,\"required_contexts\":[],\"transient_environment\":true,\"description\":\"{{`{{workflow.name}}`}}\"}"; then
      DEP_ID=$(printf '%s' "${GH_BODY}" | jq -r 'if type == "object" then (.id // empty) else empty end' 2>/dev/null || true)
      [ -n "${DEP_ID}" ] || report_failed 1 "GitHub created no ${ENVIRONMENT} Deployment for ${SHA}: $(printf '%s' "${GH_BODY}" | tr -d '\n' | cut -c1-200)"
    else
      report_failed $? "${ENVIRONMENT} Deployment not created for ${SHA}"
    fi
  }
  if [ "${STATE}" = "pending" ]; then
    # Self-heal: a run killed before its exit handler leaves its
    # Deployment in_progress forever. Before creating this run's
    # Deployment, mark every non-terminal one in the same environment
    # inactive (this run supersedes them). Best-effort: a failure here
    # is logged and never fails the step; a Deployment whose state could
    # not be read is left alone.
    if gh_api GET "${API}/deployments?environment=${ENVIRONMENT}&per_page=20"; then
      printf '%s' "${GH_BODY}" | jq -r 'if type == "array" then .[].id else empty end' 2>/dev/null | while read -r OLD; do
        if gh_api GET "${API}/deployments/${OLD}/statuses?per_page=1"; then
          OLD_STATE=$(printf '%s' "${GH_BODY}" | jq -r 'if type == "array" then (.[0].state // "none") else "unknown" end' 2>/dev/null || echo unknown)
        else
          OLD_STATE="unknown"
        fi
        case "${OLD_STATE}" in pending|in_progress|queued|none)
          if gh_api POST "${API}/deployments/${OLD}/statuses" \
               "{\"state\":\"inactive\",\"description\":\"superseded by {{`{{workflow.name}}`}}\"}"; then
            echo "Inactivated stale deployment ${ENVIRONMENT}#${OLD} (${OLD_STATE})"
          else
            echo "WARN: stale deployment ${ENVIRONMENT}#${OLD} (${OLD_STATE}) not inactivated (HTTP ${GH_CODE})"
          fi;;
        esac
      done
    else
      echo "WARN: ${ENVIRONMENT} Deployments not listed (HTTP ${GH_CODE}) — stale ones not inactivated"
    fi
    create_deployment
    DEP_STATE="in_progress"
  else
    # An empty list is retried too (same 5 attempts, 2/4/8/16s): the list
    # endpoint can lag the create, and an empty answer may be what left
    # e2e-suite-devmove-g77qv's Deployment in_progress.
    #
    # Still empty after that = the pending step never created one, so this
    # step creates it (same payload) and posts the terminal status on it. In
    # kaos e2e run 1c114130 (2026-10-18, ml-ci-build-6mfoi) the pending step's
    # create got 404 (the CI token did not reach the brand-new repo yet, see
    # ghApi), and this step used to exit 75 on the empty list, twice more in
    # new pods, with the same answer: the build was green and no Deployment
    # ever existed. The 5 lookups stay ahead of the create so a Deployment the
    # list merely lags on is not duplicated.
    _ln=1; _lw=2
    while :; do
      if gh_api GET "${API}/deployments?sha=${SHA}&environment=${ENVIRONMENT}&per_page=1"; then
        DEP_ID=$(printf '%s' "${GH_BODY}" | jq -r 'if type == "array" then (.[0].id // empty) else empty end' 2>/dev/null || true)
        [ -z "${DEP_ID}" ] || break
        if [ "${_ln}" -ge 5 ]; then
          echo "GitHub lists no ${ENVIRONMENT} Deployment for ${SHA} after ${_ln} lookups (the pending step did not create it: see its log) — creating it for the ${STATE} status"
          create_deployment
          [ -z "${DEP_ID}" ] || echo "Created ${ENVIRONMENT} Deployment #${DEP_ID} for ${SHA}"
          break
        fi
        echo "GitHub lists no ${ENVIRONMENT} Deployment for ${SHA} yet (lookup ${_ln}/5), retrying in ${_lw}s" >&2
        sleep "${_lw}"
        _ln=$((_ln + 1)); _lw=$((_lw * 2))
      else
        report_failed $? "${ENVIRONMENT} Deployment for ${SHA} not resolved — it stays in_progress"
        break
      fi
    done
    DEP_STATE="${STATE}"
  fi
  if [ -n "${DEP_ID}" ]; then
    if [ -n "${RUN_URL}" ]; then
      DPAYLOAD="{\"state\":\"${DEP_STATE}\",\"log_url\":\"${RUN_URL}\",\"environment_url\":\"${RUN_URL}\",\"description\":\"${DESC}\"}"
    else
      DPAYLOAD="{\"state\":\"${DEP_STATE}\",\"description\":\"${DESC}\"}"
    fi
    if gh_api POST "${API}/deployments/${DEP_ID}/statuses" "${DPAYLOAD}"; then
      echo "Posted deployment ${ENVIRONMENT}#${DEP_ID} status: ${DEP_STATE}"
    else
      report_failed $? "deployment ${ENVIRONMENT}#${DEP_ID} status ${DEP_STATE} not posted"
    fi
  fi
fi
if [ "${REPORT_RC}" != 0 ]; then
  echo "GitHub reporting incomplete: exit ${REPORT_RC} (75 = GitHub unavailable, retried in a new pod). The build result does not depend on it: callers run this step with continueOn failed." >&2
fi
exit "${REPORT_RC}"
{{- end }}

{{/*
The status step's retry: preemptionRetry plus exit 75, gh_api's "GitHub stayed
unavailable" or "the CI token does not reach the repo yet" (404, see ghApi).
Same limit and backoff (30s, then 60s) as cloneRetry, which waits out the same
token re-scope for the clone (0.12.109): an outage gets ~2 minutes on top of
the in-pod retries, a not-yet-reachable repo ~90s plus pod start-up. Not
lengthened for the 404: the pending step runs before the clone, so a longer
budget would hold the build back further, and a pending step that runs out of
budget no longer loses the Deployment — the terminal step creates it (see
githubStatusReport). Re-running is safe: the commit status and the terminal
Deployment status are idempotent, a re-run pending step inactivates the
Deployment an earlier attempt created before creating its own, and a re-run
terminal step finds the Deployment an earlier attempt created.
*/}}
{{- define "kubecore-ci-workflows.githubReportRetry" -}}
retryStrategy:
  limit: "2"
  retryPolicy: Always
  expression: 'lastRetry.status == "Error" or lastRetry.message matches "imminent node shutdown" or lastRetry.exitCode == "75"'
  backoff:
    duration: "30s"
    factor: "2"
{{- end }}

{{/*
kaos-lib delivery (PRD novelcore/kaos#1147): writes files/kaos-lib.py to
/tmp/kaos-lib.py, the CI side of the contract (the spec a build installs, what it
reports back in pipeline-images, the support verdict, the bump pull request).
Tested in tests/kaos-lib. Caller: python3 + PyYAML (tooling.toolboxImage).
*/}}
{{- define "kubecore-ci-workflows.kaosLibScript" -}}
cat > /tmp/kaos-lib.py <<'KAOSLIBEOF'
{{ .Files.Get "files/kaos-lib.py" }}
KAOSLIBEOF
{{- end }}

{{/*
The dataset pickers' choices, their digest and the fill of every input's form field (PRD
novelcore/kaos#1283 D-05, PRD novelcore/kaos#1911 D-15), shared by the
render (hera-enhance-commit) and the drift check (ml-ci-reconcile): one definition, so the digest
a render records is the digest the check compares. Tested in tests/dataset-choices.
Caller: python3 (tooling.toolboxImage / tooling.kubectlImage).
*/}}
{{- define "kubecore-ci-workflows.datasetChoicesScript" -}}
cat > /tmp/dataset-choices.py <<'DATASETCHOICESEOF'
{{ .Files.Get "files/dataset-choices.py" }}
DATASETCHOICESEOF
{{- end }}

{{/*
Pipeline lint (PRD novelcore/kaos#1682 F-02, PRD novelcore/kaos#2017 F-55): the kaos-lib wheel the PR gate runs.
The wheel is the platform's own: `prepare` takes it from the app's pipeline-context (kaosLib.spec, a
registry wheel with its #sha256=), else from the chart's optional pin (pipelineLint.kaosLibWheelUrl,
empty by default), else the gate is skipped. prepare writes the choice to ${LINT_DIR}/wheel.json
(url, sha256, ruleset, doc_base) and `run`, a separate pod, reads it with lint_load.
The wheel is NOT pip-installed: lint_fetch downloads the one file and checks its sha256; lint_unpack
unzips it. kaos_lib/lint/standalone.py then runs the linter with the standard library and PyYAML alone
(the toolbox image has no requests or packaging), so the gate runs the very module `kaosctl lint` runs.
Run it as `python3 -I "$LINT_CLI" ...` from outside the app checkout.
Caller: python3 (tooling.toolboxImage), sha256sum, jq; /workspace mounted.
*/}}
{{- define "kubecore-ci-workflows.pipelineLintWheel" -}}
LINT_DIR=/workspace/lint
LINT_WHEEL_URL=""; LINT_WHEEL_SHA256=""; LINT_RULESET=""; LINT_DOC_BASE=""
lint_load() {
  [ -s "${LINT_DIR}/wheel.json" ] || return 1
  LINT_WHEEL_URL=$(jq -r '.url // ""' "${LINT_DIR}/wheel.json") || return 1
  LINT_WHEEL_SHA256=$(jq -r '.sha256 // ""' "${LINT_DIR}/wheel.json") || return 1
  LINT_RULESET=$(jq -r '.ruleset // ""' "${LINT_DIR}/wheel.json") || return 1
  LINT_DOC_BASE=$(jq -r '.doc_base // ""' "${LINT_DIR}/wheel.json") || return 1
  [ -n "${LINT_WHEEL_SHA256}" ] && [ -n "${LINT_RULESET}" ]
}
lint_verify() {
  echo "${LINT_WHEEL_SHA256}  ${LINT_DIR}/kaos-lib.whl" | sha256sum -c - >/dev/null 2>&1
}
lint_fetch() {
  _n=1
  while [ "${_n}" -le 3 ]; do
    python3 - "${LINT_WHEEL_URL}" "${LINT_DIR}/kaos-lib.whl" <<'FETCHEOF' && lint_verify && return 0
import sys, urllib.request
with urllib.request.urlopen(sys.argv[1], timeout=60) as r, open(sys.argv[2], "wb") as f:
    f.write(r.read())
FETCHEOF
    _n=$((_n + 1)); sleep 5
  done
  return 1
}
lint_unpack() {
  lint_verify || return 1
  python3 - "${LINT_DIR}/kaos-lib.whl" /tmp/kaos-lib-lint <<'UNPACKEOF'
import sys, zipfile
zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])
UNPACKEOF
  LINT_CLI=/tmp/kaos-lib-lint/kaos_lib/lint/standalone.py
}
{{- end }}

{{/*
The `pipeline-lint` commit status on the PR head SHA. post_status STATE DESCRIPTION: one status
(context pipeline-lint, target_url = this Argo run), through gh_api (retries transient answers,
returns 75 when GitHub stays unavailable). The description is cut to GitHub's 140 characters.
Caller: ghApi included; API, AUTH, ACCEPT, SHA, RUN_URL set; image has curl and jq.
*/}}
{{- define "kubecore-ci-workflows.pipelineLintStatus" -}}
post_status() {
  _payload=$(jq -nc --arg s "$1" --arg d "$(printf '%s' "$2" | cut -c1-140)" --arg u "${RUN_URL}" \
    '{state: $s, description: $d, context: "pipeline-lint"} + (if $u != "" then {target_url: $u} else {} end)')
  if gh_api POST "${API}/statuses/${SHA}" "${_payload}"; then
    echo "Posted commit status pipeline-lint=$1 on ${OWNER_REPO}@${SHA}"
  else
    _rc=$?
    echo "ERROR: commit status pipeline-lint=$1 not posted (HTTP ${GH_CODE})" >&2
    return "${_rc}"
  fi
}
{{- end }}
